configurações
=> npm install express
=> npm install body-parser
=> npm install dotenv

vamos configurar tudo Okay, e mandar na aplicação.