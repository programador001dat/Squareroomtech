Preparando o modelo do nosso usuario.
=> vamos varrer esse banco de dados atrás de quem?