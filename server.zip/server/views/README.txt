Nesta pasta views você pode servir arquivos de maneira estática!
=> paginas HTML
