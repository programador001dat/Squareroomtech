Nesta pasta public você pode servir arquivos de maneira estática!
=> style.css
=> imagens
=> videos