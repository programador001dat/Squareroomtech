Controlador?
Se o usuario contém dentro do nosso /models autorize
Se não levante um erro.